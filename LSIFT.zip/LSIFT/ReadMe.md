Main：AME-LSIFT
The entire project can be derived from: 
url: https://pan.baidu.com/s/1qVc2NG3X5rW_DG8bXE3NzA?pwd=w41k 
code: w41k